A Pen created at CodePen.io. You can find this one at http://codepen.io/abhisharma2/pen/vEKWVo.

 Simple timeline abstraction for an email workflow approval process we have with one of our internal tools