A Pen created at CodePen.io. You can find this one at http://codepen.io/jen-huang/pen/LENZGX.

 Timeline with animated items that appear on hover of the corresponding time slot